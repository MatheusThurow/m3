using Godot;
using System;

public partial class espinho_s : Area2D
{

private int contador = 0;

[Export]private bool direcao = true;
[Export]private bool progressivo = true;
[Export]private int distanciaMaxima = 40;
private int p;

    public override void _Ready()
    {
        if(progressivo){
            p = 1;
        } else 
        {
            p = -1;
        }
    }

  public override void _Process(double delta)
{
    if (direcao)
    {
        GlobalPosition += new Vector2(p * 40.0f * (float)delta, 0);
    }
    else
    {
        GlobalPosition += new Vector2(0, p * 40.0f * (float)delta);
    }

    if (contador >= distanciaMaxima)
    {
        contador = 0;
        p *= -1;
    }
    contador++;
}
    private void EntrouNoEspinho(Node body)   //quando um corpo entra no espinho.
    {
        if (body is Jogador jogador)
        {
            //jogador.ReduzirVida();
            jogador.ReturnToSavePoint();    //chama a função para retornar ao ponto de salvamento do jogador
            jogador.AtualizarImagemVida();
            GD.Print("Espetado");   //fala que o jogador foi espetado no console
        }
    }


}
