using Godot; // Importa o namespace do Godot para ter acesso às classes e funcionalidades do motor
using System;

public partial class testeMenu : Node2D
{
    private void OnBodyEntered(Node body)
    {
        if (body is Jogador jogador)
        {
            GetTree().ChangeSceneToFile("res://mapa_1.tscn");
        }
    }
}
