using Godot;
using System;

public partial class BlocoQueSome1 : Area2D
{
    private StaticBody2D bloco;
    private Timer tempo;
    private bool pisou = false;
    private bool sumiu = false;

    public override void _Ready()
    {   //tempo recebe o nó Timer
        GD.Print("teste1"); 
        tempo = GetNode<Timer>("Timer");
        bloco = GetNode<StaticBody2D>("StaticBody2D");
    }
    public override void _Process(double delta)
    {
        if(tempo.TimeLeft < 0.1f && pisou)
        {
            pisou =false;
            sumiu = true;
            GD.Print("teste2");
            RemoveChild(bloco); //retira o bloco do jogo
            tempo.Start(2); //Tempo p/ o bloco reaparecer
        }
        else if(tempo.TimeLeft < 0.1 && sumiu)
        {   GD.Print("teste2/2");
            sumiu = false;
            AddChild(bloco);    //recoloca o bloco no jogo
        }
    }
    public void PisouNoBloco1(Node2D body)
    {
        if(body is Jogador)
        {
            GD.Print("teste3"); 
            tempo.Start(1.5); //inicia contagem regressiva de 5 seg
            pisou = true;   //indica que já pisou
        }
    }
}   //fim da classe BlocoQueSome1
