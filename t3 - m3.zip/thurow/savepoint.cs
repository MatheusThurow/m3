using Godot; // Importa o namespace do Godot para ter acesso às classes e funcionalidades do motor
using System;

public partial class savepoint : Node2D
{
    private bool estaDentro = false;

    public override void _Process(double delta)
    {
        if(Input.IsActionPressed("salvar") && estaDentro){
            //jogador.SavePosition(); // chama SavePosition do jogador para salvar a posição "atual" (referente ao savepoint)
            GetTree().CallGroup("GrupoJogador", "SavePosition");
            GD.Print("savepoint definido"); // mostra "savepoint definido" no console
        }
    }

    private void OnBodyEntered(Node body)
    {
        if (body is Jogador jogador)
        {
            estaDentro = true;
        }
    }

    private void OnBodyExited(Node body)
    {
        if (body is Jogador jogador)
        {
            estaDentro = false;
        }
    }

}
