using Godot;
using System;

public partial class life : Node2D
{
    private void OnBodyEntered(Node body)   //quando um corpo entra no espinho.
    {
        if (body is Jogador jogador)
        {
            if (jogador.vida <= 2)
            {
                QueueFree();
                GD.Print("+ Vida");
                jogador.AumentarVida();
                jogador.AtualizarImagemVida();
            }
        }
    }
}
