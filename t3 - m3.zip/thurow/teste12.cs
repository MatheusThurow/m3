using Godot;
using System;

public partial class teste12 : Node2D
{
    private void OnAreaBodyEntered(Node body)   //quando um corpo entra no espinho.
    {
        if (body is Jogador jogador)
        {
            
            //jogador.ReduzirVida();
            jogador.ReturnToSavePoint();    //chama a função para retornar ao ponto de salvamento do jogador
            jogador.AtualizarImagemVida();
            GD.Print("Espetado");   //fala que o jogador foi espetado no console
        }
    }
}
