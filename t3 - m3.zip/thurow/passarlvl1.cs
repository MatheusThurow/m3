using Godot; // Importa o namespace do Godot para ter acesso às classes e funcionalidades do motor
using System;

public partial class passarlvl1 : Node2D
{
    private void OnBodyEntered(Node body)
    {
        if (body is Jogador jogador)
        {
            GetTree().ChangeSceneToFile("res://mapa_2___vinicios_grisa.tscn");
            jogador.vida = 3;
            jogador.AtualizarImagemVida();
            GD.Print("Passou Fase 1");
            diamente.contaDiamante = 3;
            jogador.doorSound.Play();
        }
    }
}
