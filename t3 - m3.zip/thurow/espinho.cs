using Godot;
using System;

public partial class espinho : Node2D
{
    private void OnAreaBodyEntered(Node body) //quando um corpo entra no espinho.
    {
        if (body is Jogador jogador)
        {
            jogador.ReturnToSavePoint();    //chama a função para retornar ao ponto de salvamento do jogador
            GD.Print("Espetado");   //fala que o jogador foi espetado
        }
    }
}
