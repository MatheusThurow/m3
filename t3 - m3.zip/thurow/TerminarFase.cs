using Godot; // Importa o namespace do Godot para ter acesso às classes e funcionalidades do motor
using System;

public partial class TerminarFase : Node2D
{
    private void OnBodyEntered(Node body)
    {
        if (body is Jogador jogador)
        {
            if (diamente.contaDiamante == 0) {
                GetTree().ChangeSceneToFile("res://menukk.tscn");
                jogador.vida = 3;
                jogador.AtualizarImagemVida();
                diamente.contaDiamante = 3;
            }
                jogador.doorSound.Play();
        }
    }
}
