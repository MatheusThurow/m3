// using Godot;
// using System;

// public class Label2 : Label
// {
//     public override void _Ready()
//     {
//         Text = "aheje";
//     }
// }
