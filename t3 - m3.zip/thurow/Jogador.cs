using Godot;
using System;

public partial class Jogador : CharacterBody2D
{
    public AudioStreamPlayer jumpSound;
    public AudioStreamPlayer doorSound;
    public AudioStreamPlayer hurtSound;
    public AudioStreamPlayer coinSound;

    //referente ao diamente da tela do jogdador
    public Sprite2D diamond;
    public Sprite2D diamond2;
    public Sprite2D diamond3;

    //referente ao coração da tela do jogador
    public Sprite2D health3;
    public Sprite2D health2;
    public Sprite2D health1;
    public Sprite2D health0;

    public int vida = 3; // valor inicial da vida do personagem
    private Vector2 velocity; // velocidade atual do jogador
    private Vector2 direction; // direção do movimento do jogador
    public const float Speed = 120.0f; // regula a velocidade do jogador
    public const float MaxJumpForce = -165.0f; // força máxima do salto
    public const float MinJumpForce = -125.0f; // força mínima do salto
    public const float MaxJumpTime = 0.2f; // tempo máximo que a tecla de salto pode ser mantida pressionada
    public const int MaxDoubleJumps = 1; // número máximo de pulos duplos permitidos 
    private int doubleJumpsLeft; // número de pulos duplos restantes
    private Vector2 initialPosition; // posição inicial do jogador
    public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle(); // Gravidade do jogador
    public Vector2 savedPosition; // posição salva do jogador
    private Vector2 savepointPosition; // posição do ponto de salvamento
    private AnimatedSprite2D animate;
    private bool isJumping; // jogador está pulando
    private float jumpForce; // força atual do salto
    private float jumpTimer; // tempo do salto

    public override void _Ready()
    {
        vida = 3;
        animate = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
        doubleJumpsLeft = MaxDoubleJumps;
        initialPosition = Position;
        savepointPosition = GlobalPosition;

        jumpSound = GetNode<AudioStreamPlayer>("Node/jumpSound");
        doorSound = GetNode<AudioStreamPlayer>("Node/doorSound");
        hurtSound = GetNode<AudioStreamPlayer>("Node/hurtSound");
        coinSound = GetNode<AudioStreamPlayer>("Node/coinSound");

        diamond = GetNode<Sprite2D>("Diamond");
        diamond2 = GetNode<Sprite2D>("Diamond2");
        diamond3 = GetNode<Sprite2D>("Diamond3");

        diamond.Visible = false;
        diamond2.Visible = false;
        diamond3.Visible = false;

        health3 = GetNode<Sprite2D>("Health3");
        health2 = GetNode<Sprite2D>("Health2");
        health1 = GetNode<Sprite2D>("Health1");
        health0 = GetNode<Sprite2D>("Health0");

        health3.Visible = true;
        health2.Visible = false;
        health1.Visible = false;
        health0.Visible = false;
    }

    public void ReduzirVida()
    {
        hurtSound.Play();
        vida -= 1; // Reduz a vida em 1 ponto
        if (vida <= 0)
        {
            GetTree().ChangeSceneToFile("res://menukk.tscn");
        }
    }

    public void AumentarVida()
    {
        vida += 1;
        if (vida >= 3)
        {
            vida = 3;
        }
    }

    public void updateDiamond() //código para atualizar o dimante na tela do jogador
    {
        if (diamente.contaDiamante == 0)
        {
            diamond.Visible =  true;
            diamond2.Visible = true;
            diamond3.Visible = true;
        }
        else if (diamente.contaDiamante == 1)
        {
            diamond.Visible = true;
            diamond2.Visible = true;
            diamond3.Visible = false;
        }
        else if (diamente.contaDiamante == 2)
        {
            diamond.Visible = true;
            diamond2.Visible = false;
            diamond3.Visible = false;
        }
        else if (diamente.contaDiamante == 3)
        {
            diamond.Visible = false;
            diamond2.Visible = false;
            diamond3.Visible = false;
        }
    }

    public void AtualizarImagemVida()   // Código para atualizar a imagem com base na quantidade de vida
    {                                   // Exemplo: Mostrar diferentes imagens para cada ponto de vida                                 

        if (vida == 3)                  // Carregar a textura ou sprite para representar 3 pontos de vida
        {
            health3.Visible = true;
            health2.Visible = false;
            health1.Visible = false;
        }
        else if (vida == 2)             // Carregar a textura ou sprite para representar 2 pontos de vida
        {
            health3.Visible = false;
            health2.Visible = true;
            health1.Visible = false;
        }
        else if (vida == 1)             // Carregar a textura ou sprite para representar 1 ponto de vida
        {
            health3.Visible = false;
            health2.Visible = false;
            health1.Visible = true;
        }
    }

    public override void _PhysicsProcess(double delta)
    {
        velocity = Velocity;

        if (!IsOnFloor())
        {
            velocity.Y += gravity * (float)delta; // aplica a gravidade quando o jogador está no ar
        }
        else
        {
            doubleJumpsLeft = MaxDoubleJumps; // zera o número de pulos duplos quando o jogador está no chão p/ voltar a pular
        }

        // verifica se a tecla de salto foi pressionada
        if (Input.IsActionJustPressed("ui_accept"))
        {
            if (IsOnFloor())
            {
                jumpSound.Play();
                isJumping = true;
                jumpForce = MaxJumpForce; //define a força máxima do salto
                jumpTimer = 0;
            }
            else if (doubleJumpsLeft > 0)
            {
                jumpSound.Play();
                isJumping = true;
                jumpForce = MaxJumpForce; //define a força máxima do salto
                jumpTimer = 0;
                doubleJumpsLeft--;
            }
        }

        if(Input.IsActionPressed("SairJogo")){
            GetTree().Quit();
        }

        if (isJumping)  //se stiver pulando:
        {
            // verifica se a tecla de salto está sendo mantida pressionada e atualiza a força do salto com base no tempo decorrido
            if (Input.IsActionPressed("ui_accept") && jumpTimer < MaxJumpTime)
            {
                jumpForce = Mathf.Lerp(MaxJumpForce, MinJumpForce, jumpTimer / MaxJumpTime);
                jumpTimer += (float)delta;
            }
            else
            {
                isJumping = false; //o jogador parou de pular
            }
        }

        direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
        
        if (direction != Vector2.Zero)
        {
            velocity.X = direction.X * Speed;
        }
        else
        {
            velocity.X = Mathf.MoveToward(Velocity.X, 0, Speed);
        }

        if (isJumping)
        {
            velocity.Y = jumpForce; //Aplica a força de salto atual à velocidade vertical
        }

        Velocity = velocity; //Aplica a nova velocidade ao jogador

        MoveAndSlide(); //função para o jogador se mover e coledir com as coisas

        Animation(velocity); //rtualiza a animação do jogador com base em sua velocidade

        if (Position.Y > 500)   //ponto q ele cai no void e volta
        {
            ReduzirVida();
            ResetPlayer(); //reinicia o jogador se ele cair abaixo de uma determinada altura
            AtualizarImagemVida();
        }
    }

    // atualiza a animação do jogador:
    private void Animation(Vector2 velocity)
    {
        if (!IsOnFloor())
        {
            animate.Play("jump");
        }
        else
        {
            if (velocity.X != 0)
            {
                animate.Play("run");
            }
            else
            {
                animate.Play("idle");
            }
        }
        //espelhar a animação do personagem
        if (velocity.X != 0)
        {
            if (velocity.X < 0)
            {
                animate.FlipH = true; // inverte a animação
            }
            else
            {
                animate.FlipH = false; // mantém a animação normal
            }
        }
    }

    // reinicia o jogador para sua posição inicial
    private void ResetPlayer()
    {
        Position = savepointPosition;
        Velocity = Vector2.Zero;
    }

    // salva a posição atual do jogador
    public void SavePosition()
    {
        savepointPosition = Position;
    }

    // restaura a posição salva do jogador
    public void ClearSavedPosition()
    {
        Position = savepointPosition;
        savedPosition = savepointPosition;
        Velocity = Vector2.Zero;
    }

    // retorna à posição do ponto de salvamento
    public void ReturnToSavePoint()
    {
        GlobalPosition = savepointPosition;
        savedPosition = savepointPosition;
        Velocity = Vector2.Zero;
        ReduzirVida();
    }

    public void _on_BlocoQueSome1_body_entered(Node body)
    {
        if (body is BlocoQueSome1)
        {
            BlocoQueSome1 bloco = body as BlocoQueSome1;
            bloco.PisouNoBloco1(this); // Chama a função PisouNoBloco1 no bloco que some

            body.QueueFree(); // Remove o bloco que some
        }
    }

}