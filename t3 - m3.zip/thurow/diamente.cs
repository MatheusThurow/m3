using Godot;
using System;

public partial class diamente : Node2D
{
    public static int contaDiamante = 3; // contador diamante
    public void _on_body_entered(Node body) //função quando um obj estra no diamante
    {
        if (body is Jogador jogador) // Verifica se o objeto que entrou na área é o jogador
        {
            QueueFree(); // libera o nó do diamante, removendo-o do jogo
            contaDiamante--; // diminuir o contador

            jogador.coinSound.Play();


            GD.Print("quantidade de diamantes restantes: ",contaDiamante); // mostra o n° de diamantes no console
            jogador.updateDiamond();
            if (contaDiamante == 0) // se acabar...
            {
                EndMap(); // chama a função para finalizar o mapa
            }
        }
    }
    // Função para finalizar o mapa
    private void EndMap()
    {
        GD.Print("A fase acabou"); // fala que a fase acabou
    }
}
