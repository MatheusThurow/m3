using Godot; // Importa o namespace do Godot para ter acesso às classes e funcionalidades do motor
using System;

public partial class passarlvl2 : Node2D
{
    private void OnBodyEntered(Node body)
    {
        if (body is Jogador jogador)
        {
            GetTree().ChangeSceneToFile("res://mapa_3.tscn");
            jogador.vida = 3;
            jogador.AtualizarImagemVida();
            GD.Print("Passou Fase 2");
            diamente.contaDiamante = 3;
            jogador.doorSound.Play();
        }
    }
}
